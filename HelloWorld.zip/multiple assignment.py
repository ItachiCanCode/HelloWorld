# name = "Advaith Menon"
# age = 18
# attractive = False

# name, age, attractive = "Adavith Menon", 18, False

# print(name)
# print(age)
# print(attractive)

#a = 10
#b = 10
#c = 10

#a = b = c = 10

#print(a)
#print(b)
#print(c)
