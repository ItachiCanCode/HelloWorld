name = input("What is your name?: ")
age = int(input("how old are you?: "))
height = float(input("What is your height?: "))

age += 1

print("Hello "+name)
print("you are "+str(age)+" years old")
print("Your height is "+str(height)+"cm")













