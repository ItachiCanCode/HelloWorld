first_name = "Advaith"
last_name = "Menon"
full_name = first_name + " " + last_name
print("Hello "+full_name)
#print(type(name))

age = 18
#age += 1
print("Your age is: "+str(age))
#print(type(age))

height = 179.3
print("Your height is: "+str(height)+"cm")
#print(type(height))

human = True
print("Are you a human: "+str(human))
#print(type(human))

