import math

pi = 3.14

# print(round(pi))
# print(math.ceil(pi))

