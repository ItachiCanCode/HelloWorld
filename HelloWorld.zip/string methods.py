name = "advaith menon"

#print(len(name))
#print(name.find("n"))
#print(name.capitalize())
#print(name.upper())
#print(name.lower())
#print(name.isdigit())
#print(name.isalnum())
#print(name.count("a"))
#print(name.replace("v","w"))
#print(name * 69)


